public class Main {

    public static void main (String args[]) {

        //create new guessing game and play
        GuessingGame game1 = new GuessingGame("Is your animal a mammal?", "fish", "lion");
        game1.play();
    }
}
